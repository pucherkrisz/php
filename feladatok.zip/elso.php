<?php


for($a=1; $a <= 10;  $a++){
    for($b=1 ; $b <= 10; $b++){
        echo $a*$b . ' ';
    }
    echo '<br>';

}

?>