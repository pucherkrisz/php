<?php

function Registration(){
    
    
    if(isset($_POST['submit'])){
    if(!empty($_POST['email']) && !empty($_POST['psw']) && !empty($_POST['psw-repeat']) && !empty($_POST['user_name'])){
        
    $user_name = strip_tags(trim(mysqli_real_escape_string($conn, $_POST['user_name'])));
    $password = strip_tags(trim(mysqli_real_escape_string($conn, $_POST['psw'])));
    $email = strip_tags(trim(mysqli_real_escape_string($conn, $_POST['email'])));
    $password_repeat = strip_tags(trim(mysqli_real_escape_string($conn, $_POST['psw-repeat'])));
        
        if($password == $password_repeat){
         if(strlen($password) <= 8){
            if(!preg_match("#[a-z]+#", $password )){
                if(!preg_match("#[A-Z]+#", $password ) ) {
                    if(!preg_match("\d{4}", $password){
            
            } else{
                echo "A jelszónak tartalmazni  kell 4 számot!";
            }
        } else{
            echo "A jelszónak tartalmazni kell egy nagybetűt is!";
            }
    } else{
        echo "A jelszónak tartalmazni kell egy kis betűt is!";
        }
        }
        else{
            echo "A jelszónak legalább 8 karakternek kell lennie!";
        }
    } else{
            echo "A két jelszó nem egyezik!";
        }
}
    }
    
}
                       
Registration();            

?>

<!doctype html>
<html>
    <head>
    <body>
    <form action="" method="POST">
    
    <label for="email"><b>Email</b></label>
    <input type="text" placeholder="Email" name="email" required>
    
    <label for="email"><b>Username</b></label>
    <input type="text" placeholder="Username" name="user_name" required>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Password" name="psw" required>

    <label for="psw-repeat"><b>Repeat Password</b></label>
    <input type="password" placeholder="Password" name="psw-repeat" required>
    
    <button name="submit" type="submit" class="registerbtn">Register</button>

    </form> 
    </body>
    </head>
</html>
 

