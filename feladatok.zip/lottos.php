<?php

if(isset($_POST['submit'])){
    $elso = $_POST['elso'];
    $masodik = $_POST['masodik'];
    $harmadik = $_POST['harmadik'];
    $negyedik = $_POST['negyedik'];
    $otodik = $_POST['otodik'];
    
    $tomb = array($elso, $masodik, $harmadik, $negyedik, $otodik);
}

$gep = array();
for($i = 0; $i<5; $i++){
    $gep = rand(1,90);
    
    echo $gep . " ";
}

$result = array_diff($tomb , $gep);
echo $result;



?>
<!doctype html>
<html>
<head>
    <body>
    <form action="" method="post">
    <input type="text" name="elso" placeholder="Első">
    <input type="text" name="masodik" placeholder="Második">
    <input type="text" name="harmadik" placeholder="Harmadik">
    <input type="text" name="negyedik" placeholder="Negyedik">
    <input type="text" name="otodik" placeholder="Ötödik">
    <button name="submit" type="submit">Elküld</button>
    </form>
    </body>
    </head>
</html>

